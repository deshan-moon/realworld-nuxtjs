import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _9532731c = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _35721bb2 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _7860c9be = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _acd02696 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _cd6e552a = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _3107b13e = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _63732aa4 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _9532731c,
    children: [{
      path: "",
      component: _35721bb2,
      name: "home"
    }, {
      path: "/login",
      component: _7860c9be,
      name: "login"
    }, {
      path: "/register",
      component: _7860c9be,
      name: "register"
    }, {
      path: "/editor",
      component: _acd02696,
      name: "editor"
    }, {
      path: "/settings",
      component: _cd6e552a,
      name: "settings"
    }, {
      path: "/profile/:username",
      component: _3107b13e,
      name: "profile"
    }, {
      path: "/article/:slug",
      component: _63732aa4,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
