<template> 
  <div> 
    <h1>Settings Page</h1> 
  </div> 
</template> 
<script>
export default { 
  middleware: 'authenticated',
  name: "settings" 
};
</script> 
<style>
</style>